
package mainclass;
public class Mainclass {        
    public static void main(String[] args) {
        Action action=new Action();
        action.play();
              
    }
}
